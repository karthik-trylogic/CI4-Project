<?php

namespace App\Controllers;

use App\Libraries\Hash;

class Auth extends BaseController
{
    public function __construct()
    {
        helper(['url','form']);
    }
    public function index()
    {
       return view('auth/login');
    }
    public function register()
    {
       return view('auth/register');       
    }
    public function save()
    {
        $captcha_response = trim($this->request->getVar('g-recaptcha-response'));
        if( $captcha_response != '')
        {
            $keySecret = '6Le9etwdAAAAAMtNYETot0zBrffywLxiJyZ691Ib';

            $check = array(
                'secret'=>$keySecret,
                'response'=> $this->request->getVar('g-recaptcha-response')
            );
            $startProcess = curl_init();

            curl_setopt($startProcess,CURLOPT_URL, "https://www.google.com/recaptcha/api/siteverify");

            curl_setopt($startProcess,CURLOPT_POST,true);

            curl_setopt($startProcess,CURLOPT_POSTFIELDS,http_build_query($check));

            curl_setopt($startProcess,CURLOPT_SSL_VERIFYPEER,false);

            curl_setopt($startProcess,CURLOPT_RETURNTRANSFER,true);

            $recieveData = curl_exec($startProcess);

            $finalResponse = json_decode($recieveData,true);

            if($finalResponse['success'])
            {
                $validation = $this->validate([
                'fname'=>
                ['rules'=>'required',
                'errors'=>['required'=>'First name is required']
                ],

                'lname'=>
                ['rules'=>'required',
                'errors'=>['required'=>'Last name is required']
                ],

                'number'=>
                ['rules'=>'required',
                'errors'=>['required'=>'Mobile Number name is required','regex_match'=>'Enter 10 Digit number']
                ],

                'dob'=>
                ['rules'=>'required',
                'errors'=>['required'=>'Date of Birth is required']
                    ],

                'email'=>
                ['rules'=>'required|valid_email|is_unique[users.email]',
                'errors'=>['required'=>'First name is required','valid_email'=>'Enter Valid Email Id','is_unique'=>'Email id already exist,Try another one.']
                ],
            
                'password'=>
                ['rules'=>'required|min_length[5]|max_length[12]',
                'errors'=>['required'=>'Password is required','min_length'=>'Password must contains minimum 5 characters','max_length'=>'Password must not exceed minimum 12 characters']
                ],

                'subscription'=>
                ['rules'=>'required',
                'errors'=>['required'=>'Subscribe the item that you wish']
                ],

                'privillege'=>
                ['rules'=>'required',
                'errors'=>['required'=>'Select User/Admin ']
                ]

            ]);

            if(!$validation)
            {
                return view('auth/register',['validation'=>$this->validator]);
            }
            else 
            {
           
                $fname = $this->request->getVar('fname');
                $lname = $this->request->getVar('lname');
                $number = $this->request->getVar('number');
                $dob = $this->request->getVar('dob');
                $email = $this->request->getVar('email');
                $password = $this->request->getVar('password');
                $country = $this->request->getVar('country');
                $subscription = $this->request->getVar('subscription');
                $privillege= $this->request->getVar('privillege'); 
                
                $usersModel = new \App\Models\UsersModel();
                $result = $usersModel->where('privillegeId','1')->find();
                $arrayResult = $result['0'];
                if($privillege == $arrayResult['privillegeId']){
                    return redirect()->back()->with('fail','Admin is already activated !');
                }
                else 
                {
                    $values = [
                        'firstName'=>$fname,
                        'lastName'=>$lname,
                        'phoneNumber'=>$number,
                        'dateOfBirth'=>$dob,
                        'email'=>$email,
                        'password'=>Hash::make($password),
                        'country'=>$country,
                        'subscription'=>$subscription,
                        'privillegeId'=>$privillege
                    ];

                    $usersModel = new \App\Models\UsersModel();
                    $query = $usersModel->insert($values);
                    if(!$query){
                        return redirect()->back()->with('fail','something went wrong');
                    }
                    else{
                        $last_id = $usersModel->insertId();
                        $to = $email;
                        $subject = 'Account Activation-GoPHP';
                        $message = 'Haii, <br>Your Account created succesfully. Please click the below link to activate your account<br>'
                                    .'<a href="'.base_url().'/auth/verify/'.$last_id.'" target="_blank">Activate now</a><br><br>Team';
                
                        $email = \config\Services::email();
                        
                        $email ->setTo($to);
                        $email ->setFrom('karthikplr123@gmail.com','Info');
                        $email ->setSubject($subject);
                        $email ->setMessage($message);
                        if($email->send()){
                            return redirect()->to('auth/register')->with('success','Account created successfully. Check email to activate your account');
                        }
                        else{
                            $data = $email->printDebugger(['headers']);
                            print_r($data);
                        }
                    }
                }
            }

            }
            else 
            {
                return redirect()->back()->with('fail','something went wrong');
            }
        }
        else{
            return redirect()->back()->with('fail','Enter Captcha');
        }
    
    }
    public function verify($last_id)
    {
        $usersModel = new \App\Models\UsersModel();
        $query = $usersModel->update($last_id,['activation'=>'1']);
        echo"Account verified";
    }
    function check()
    {
        $validation = $this->validate([           
            'email'=>
            ['rules'=>'required|valid_email|is_not_unique[users.email]',
            'errors'=>['required'=>'First name is required','valid_email'=>'Enter Valid Email Id','is_not_unique'=>'Enter Registered Email']
            ],
        
            'password'=>
            ['rules'=>'required|min_length[5]|max_length[12]',
            'errors'=>['required'=>'Password is required','min_length'=>'Password must contains minimum 5 characters','max_length'=>'Password must not exceed minimum 12 characters']
            ]
        ]);
        if(!$validation)
        {
         return view('auth/login',['validation'=>$this->validator]);
        }else{
            $email      = $this->request->getVar('email');
            $password   = $this->request->getVar('password');
            $usersModel = new \App\Models\UsersModel();
            $user_info = $usersModel->where('email',$email)->where('activation','1')->first();
            if($user_info)
            {
                $check_password = Hash::check($password,$user_info['password']);
                if(!$check_password){
                    session()->setFlashdata('fail','Incorrect Password');
                    return redirect()->to('/auth')->withInput();
                }
                else{
                    $user_id = $user_info['userId'];
                    session()->set('loggedUser',$user_id);
                    return redirect()->to('/dashboard');
                }
            }
            else{
                session()->setFlashdata('fail','Please Activate your Account');
                return redirect()->to('/auth')->withInput();
            }
        }
    }
    function logout()
    {
        if(session()->has('loggedUser'))
        {
            session()->remove('loggedUser');
            return redirect()->to('/auth?access=out')->with('fail','You are logged out');
        }
    }
    function edit($userId)
    {
       
        $usersModel = new \App\Models\UsersModel();
        $result = $usersModel->where('userId',$userId)->first();

        $subscriptionModel = new \App\Models\SubscriptionModel();
        $subscription = $subscriptionModel->findAll();

        $data = [
            'subscription'=>$subscription,
            'result'=>$result
        ];
        return view('dashboard/edit',$data);       
       
    }
    function update($userId)
    {
        $fname = $this->request->getVar('fname');
        $lname = $this->request->getVar('lname');
        $number = $this->request->getVar('number');
        $dob = $this->request->getVar('dob');
        $email = $this->request->getVar('email');
        $password = $this->request->getVar('password');
        $country = $this->request->getVar('country');
        $subscription = $this->request->getVar('subscription');

        $usersModel = new \App\Models\UsersModel();
        $query = $usersModel->update($userId,['firstName'=>$fname,
        'lastName'=>$lname,
    	'phoneNumber'=>$number,
        'dateOfBirth'=>$dob,
        'email'=>$email,
        'country'=>$country,
        'subscription'=>$subscription]);
        
        if(!$query){
            return redirect()->back()->with('fail','something went wrong');
        }
        else{
            return redirect()->to('/dashboard')->with('success','Updated Successfully');
        }     
    }
}
?>