<?php

namespace App\Controllers;

class Dashboard extends BaseController
{
    public function index()
    {
        $usersModel = new \App\Models\UsersModel();
        $loggedUserId=session()->get('loggedUser');
        $userInfo=$usersModel->find($loggedUserId);
        $show = $usersModel->where('privillegeId',0)->where('status',1)->find();
        $data = [
            'title'=>'Dashboard',
            'show'=>$show,
            'userInfo'=>$userInfo
        ];
        return view('dashboard/index',$data);
    }
    public function delete($userId){
        $usersModel = new \App\Models\UsersModel();
        $query = $usersModel->update($userId,['status'=>'0']);

        if(!$query){
            return redirect()->back()->with('fail','something went wrong');
        }
        else{
            return redirect()->to('/dashboard')->with('success','Deleted Successfully');
        }
    }

}
