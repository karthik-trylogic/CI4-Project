<?php

namespace App\Models;

use CodeIgniter\Model;

class UsersModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'userId';
    protected $allowedFields = ['firstName','lastName','phoneNumber','dateOfBirth','email','password','country','subscription','privillegeId','status','activation'];

}
?>