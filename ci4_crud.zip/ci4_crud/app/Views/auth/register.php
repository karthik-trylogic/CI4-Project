<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <link rel="stylesheet" href="<?= base_url('bootstrap/css/bootstrap.min.css') ?>">
    <style>
        @media only screen and (max-width: 600px) 
        {
        .example {min-width: 1000px;}
        }
        input 
        {
        outline: none !important;
        }
        label
        {
            color:green;
            font-weight:100px;
            font-size:20px !important;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row d-flex justify-content-center" style="margin-top:45px;">
            <div class="col-lg-10 col-md-10 col-sm-10">
                <form action="<?= base_url('auth/save'); ?>" method="post" autocomplete="off">
                <?= csrf_field(); ?>
                <?php if(!empty(session()->getFlashdata('fail'))) : ?>
                    <div class="alert alert-danger hide-it"><?= session()->getFlashdata('fail'); ?></div>
                <?php endif ?>
                <?php if(!empty(session()->getFlashdata('success'))) : ?>
                    <div class="alert alert-success hide-it"><?= session()->getFlashdata('success'); ?></div>
                <?php endif ?>
                <div class="card">
                    <div class="card-header" style="background:#6495ED;color:white;"><h3>Register<h3></div>
                    <div class="card-body">
                        <table border="0" width="100%" cellpadding="5" cellspacing="5">
                            <tr>
                                <th width="25%">First Name</th>
                                <th width="25%">Last Name</th>
                                <th width="25%">Phone Number</th>
                                <th width="25%">Date of birth</th>
                            </tr>
                            <tr>
                                <td> <input type="text" style="width:80%;" class="form-control input-sm" name="fname" value="<?= set_value('fname')?>" >
                                    <span class="text-danger"><?= isset($validation) ? display_error($validation,'fname') : '' ?></span>
                                </td>
                                <td> <input type="text" style="width:80%;" class="form-control input-sm" name="lname" value="<?= set_value('lname')?>" >
                                    <span class="text-danger"><?= isset($validation) ? display_error($validation,'lname') : '' ?></span>
                                </td>
                                <td>
                                    <input type="text" onchange="mobileValidation(this.value);" style="width:80%;" class="form-control input-sm" name="number" value="<?= set_value('number')?>" >
                                    <span class="text-danger"><?= isset($validation) ? display_error($validation,'number') : '' ?></span>
                                </td>
                                <td> <input type="date" style="width:100%;" class="form-control datepicker input-sm" name="dob" value="<?= set_value('dob')?>" >
                                    <span class="text-danger"><?= isset($validation) ? display_error($validation,'dob') : '' ?></span>
                                </td>
                            </tr>
                            <tr>                                
                                <th width="25%">Email</th>
                                <th width="25%">Password</th>
                                <th width="25%">Country</th>
                                <th width="25%">Subscription</th>
                            </tr>
                            <tr>
                               
                                <td> <input type="text" style="width:80%;" class="form-control input-sm" name="email" value="<?= set_value('email')?>">
                                    <span class="text-danger"><?= isset($validation) ? display_error($validation,'email') : '' ?></span>
                                </td>
                                <td> <input type="password" style="width:80%;" class="form-control input-sm" name="password" >
                                    <span class="text-danger"><?= isset($validation) ? display_error($validation,'password') : '' ?></span>
                                </td>
                                <td> <input type="text" style="width:80%;" class="form-control input-sm" name="country" readonly value="UK">
                                    <span class="text-danger"><?= isset($validation) ? display_error($validation,'country') : '' ?></span>
                                </td>
                                <td> 
                                    <select name="subscription" class="form-control" value="<?= set_value('subscription')?>">
                                        <option value="">-select-</option>
                                        <option value="1">-Story-</option>
                                        <option value="2">-Comment-</option>
                                        <option value="3">-Poll-</option>
                                    </select>
                                    <span class="text-danger"><?= isset($validation) ? display_error($validation,'subscription') : '' ?></span>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="form-group">
                                        <div class="g-recaptcha" data-sitekey="6Le9etwdAAAAANtbxvcrAYGXGA7uMJT7P3HUtCMY"></div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="4" align="center">
                                    <input type="radio" id="html" name="privillege" value="1">
                                    <label for="html">Admin</label> &nbsp;&nbsp;&nbsp;
                                    <input type="radio" id="css" name="privillege" value="0">
                                    <label for="css">User</label><br>
                                    <span class="text-danger"><?= isset($validation) ? display_error($validation,'privillege') : '' ?></span>
                                </td>
                            </tr>
                            <tr>
                               <td colspan="4" align="center">
                                <!-- <span class="text-danger"><b><?= isset($validation) ? display_error($validation,'email') : '' ?></b></span>
                                <br>
                                <span class="text-danger"><b><?= isset($validation) ? display_error($validation,'password') : '' ?></b></span> -->
                                <button type='submit' name='register' class='btn submitBtn btn-lg d-flex justify-content-center' style="width:30%;background-color:#5F9EA0;color:white;letter-spacing:0.1em;"><b>REGISTER</b></button>
                                </td>
                            </tr>
                        </table>
                        
                        <br>
                        <a class="text-danger" href="<?= site_url('auth') ?>">Already have an account ? Login</a>
                    </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://www.google.com/recaptcha/api.js"></script>
<script>
    $(function() {    
    $(".hide-it").fadeOut(6000);
});
function mobileValidation(val)
{
    var mobile =val;
    if(mobile.length != 13)
    {
        alert('Add UK numbers only(Please attach country code +44)');
    }
}
</script>
</html>