<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="//cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css"> -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.css">  
    <title>Dashboard</title>
</head>
<body>
    <div class="container-fluid" style="background-color:#6f42c1">
        <div class="container pt-2 pb-2">
        <h4 class="text-center text-white">Welcome <?= $userInfo['firstName'].$userInfo['lastName'] ?></h4>
        </div>
    </div>    
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container">
    <!-- <a class="navbar-brand" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button> -->
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Link</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Dropdown
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="#">Action</a></li>
            <li><a class="dropdown-item" href="#">Another action</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
        </li>
      </ul>
      <div class="d-flex">
        <a href="<?= site_url('auth/logout');?>" class="navbar-brand text-danger">Logout</a>
       </div>
    </div>
    </div>
    </nav>
    <div class="container">
        <div class="row" style="margin-top:40px">
            <div class="col-md-12">
                 <?= csrf_field(); ?>
                    <?php if(!empty(session()->getFlashdata('fail'))) : ?>
                        <div class="alert alert-danger hide-it"><?= session()->getFlashdata('fail'); ?></div>
                    <?php endif ?>
                    <?php if(!empty(session()->getFlashdata('success'))) : ?>
                        <div class="alert alert-success hide-it"><?= session()->getFlashdata('success'); ?></div>
                    <?php endif ?><?php 
                $content = $userInfo['subscription'];
                if($content == 1){
                    $contents = "STORY"; 
                } 
                else if($content == '2'){
                    $contents = "COMMENT"; 
                }
                else{
                    $contents = "POLL"; 
                } 
                $privillegeId = $userInfo['privillegeId'];
                if( $privillegeId == '1')
                { ?>  
                <div>    
                <div style="padding-bottom:3em">      
                <table class="table table-bordered table-responsive" id="myTable">                  
                    <thead>
                        <tr>
                            <th>Si,No</th>
                            <th>firstName</th>
                            <th>lastName</th>
                            <th>phoneNumber</th>
                            <th>dateOfBirth</th>
                            <th>email</th>
                            <th>country</th>
                            <th>subscription</th>
                            <th>Activation Status</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>                          
                        <?php
                        if(!empty($show))
                        {
                         $i=1; 
                        foreach ($show as $k) { 
                            if($k['activation']==1){
                                $activationStatus='<td align="center" style="color:green"><b>TRUE</b></td>';
                            }
                            else if($k['activation']==0)
                            {
                                $activationStatus='<td align="center" style="color:red"><b>FALSE</b></td>';
                            }
                            if($k['subscription']==1){
                                $subscription = 'STORY';
                            } 
                            else if($k['subscription']==2){
                                $subscription = 'COMMENT';
                            }
                            else 
                            {
                                $subscription = 'POLL';
                            }
                        ?>
                        <tr>
                        <td><?= $i++ ?></td>
                        <td><?= $k['firstName'] ?></td>
                        <td><?= $k['lastName'] ?></td>
                        <td><?= $k['phoneNumber'] ?></td>
                        <td><?= date("d/m/Y", strtotime($k['dateOfBirth'])) ?></td>
                        <td><?= $k['email'] ?></td>
                        <td><?= $k['country'] ?></td>
                        <td><?=  $subscription ?></td>
                        <?=  $activationStatus ?>
                        <td> <a class="btn btn-primary btn-sm" href="<?php echo base_url('auth/edit/'.$k['userId']); ?>">Edit</a></td>
                        <td> <a class="btn btn-danger btn-sm" onclick="deleteConfirm(<?= $k['userId'] ?>);" href="#">Delete</a></td>
                        </tr>
                        <?php }
                        } else {?>
                        <tr>
                            <td colspan="10" align="center">No Records Found</td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
                        </div>
                </div>
               <?php } else {?>
                <div class="bg-white shadow-sm">
                    <div class="container">
                        <table  width="100%">
                            <tr>
                                <td align="center">You have subscribed <b><?php echo $contents ?></b></td>                       
                            </tr>
                        </table>
                    </div>
               </div>
                <?php } ?>
            </div>
        </div>
    </div>
</body>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>
<script>
    $(document).ready( function () {
    $('#myTable').DataTable();
} );
$(function() {    
    $(".hide-it").fadeOut(5000);
});
function deleteConfirm(id)
{
    // alert(id);
    if(confirm("Are you sure want to delete this user ?")){
        window.location.href='<?php echo base_url('dashboard/delete') ?>/'+id;
    }
}
</script>
</html>

                     
                        